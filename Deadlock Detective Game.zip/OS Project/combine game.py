import tkinter as tk
from tkinter import messagebox, ttk


# Game Configuration for 5 Levels (More Complex Layouts)
LEVELS = [
    {"blocks": [(2, 1), (2, 2)], "player_start": (4, 0), "goal": [(0, 4)], "walls": [(1, 1), (3, 2)], "obstacles": [(1, 3)]},
    {"blocks": [(1, 1), (3, 3), (2, 4)], "player_start": (4, 0), "goal": [(0, 4), (4, 4)], "walls": [(2, 2), (1, 2)], "obstacles": [(2, 3), (3, 1)]},
    {"blocks": [(0, 1), (1, 1), (1, 2)], "player_start": (4, 0), "goal": [(0, 4)], "walls": [(2, 3)], "obstacles": [(3, 4), (0, 0)]},
    {"blocks": [(1, 1), (1, 2), (3, 1)], "player_start": (4, 0), "goal": [(0, 3), (3, 4)], "walls": [(2, 1)], "obstacles": [(0, 2), (4, 3)]},
    {"blocks": [(2, 2), (3, 3), (3, 1)], "player_start": (4, 0), "goal": [(0, 4), (4, 4)], "walls": [(2, 0), (1, 3)], "obstacles": [(3, 2), (0, 1)]},
]


class DeadlockDetectiveGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Deadlock Detective Game")
        self.root.geometry("800x600")
        self.root.config(bg="#1d3557")  # Background color

        # Initialize game data
        self.level = 1
        self.score = 0
        self.setup_level()

        # Create main menu
        self.main_menu()

    def setup_level(self):
        """Set up the game level's processes, resources, and requirements."""
        base_resources = self.level + 2  # Resources grow with levels
        self.processes = [f"P{i+1}" for i in range(self.level + 2)]  # More processes per level
        self.resources = {f"R{i+1}": base_resources for i in range(3)}
        self.max_requirements = {
            p: {r: base_resources // 2 + i for i, r in enumerate(self.resources)} for p in self.processes
        }
        self.allocated = {p: {r: 0 for r in self.resources} for p in self.processes}
        self.available_resources = self.resources.copy()

    def main_menu(self):
        """Display the main menu."""
        self.clear_frame()

        tk.Label(self.root, text="Deadlock Detective", font=("Algerian", 35, "bold"), fg="#f1faee", bg="#1d3557").pack(pady=100)

        tk.Button(self.root, text="Start Process Game", font=("Showcard Gothic", 16), command=self.start_game, bg="#457b9d", fg="#f1faee").pack(pady=10)
        tk.Button(self.root, text="Start Block Game", font=("Showcard Gothic", 16), command=self.start_block_game, bg="#457b9d", fg="#f1faee").pack(pady=10)
        tk.Button(self.root, text="Quit", font=("Showcard Gothic", 16), command=self.root.quit, bg="#e63946", fg="#f1faee").pack(pady=10)

    def start_game(self):
        """Start the Deadlock Detective game."""
        self.clear_frame()
        self.create_game_ui()

    def start_block_game(self):
        """Start the Deadlock Block game."""
        self.clear_frame()
        new_root = tk.Tk()
        game = DeadlockGame(new_root, LEVELS[0])  # Starting the block game
        new_root.mainloop()

    def clear_frame(self):
        """Clear the current frame."""
        for widget in self.root.winfo_children():
            widget.destroy()

    def create_game_ui(self):
        """Create the game interface."""
        # Title and Progress
        tk.Label(self.root, text=f"Level {self.level}", font=("Rockwell", 18, "bold"), fg="#f1faee", bg="#1d3557").pack(pady=10)
        self.progress_bar = ttk.Progressbar(self.root, orient="horizontal", length=500, mode="determinate", maximum=100)
        self.progress_bar.pack(pady=10)

        # Display Resources
        self.resource_frame = tk.Frame(self.root, bg="#1d3557")
        self.resource_frame.pack(pady=10)
        tk.Label(self.resource_frame, text="Available Resources:", font=("Rockwell", 16, "bold"), fg="#f1faee", bg="#1d3557").grid(row=0, column=0, columnspan=2)
        self.resource_display = tk.Label(self.resource_frame, text=self.get_resource_display(), font=("Times New Roman", 12), fg="#f1faee", bg="#1d3557")
        self.resource_display.grid(row=1, column=0, columnspan=2)

        # Current Allocations
        tk.Label(self.root, text="Current Allocations:", font=("Rockwell", 16, "bold"), fg="#f1faee", bg="#1d3557").pack()
        self.allocation_display = tk.Label(self.root, text=self.get_allocation_display(), font=("Times New Roman", 12), fg="#f1faee", bg="#1d3557")
        self.allocation_display.pack()

        # Request Section
        self.request_frame = tk.Frame(self.root, bg="#1d3557")
        self.request_frame.pack(pady=20)
        tk.Label(self.request_frame, text="Submit Resource Request:", font=("Rockwell", 16, "bold"), fg="#f1faee", bg="#1d3557").grid(row=0, column=0, columnspan=2, pady=5)

        tk.Label(self.request_frame, text="Select Process:", fg="#f1faee", bg="#1d3557").grid(row=1, column=0, pady=5)
        self.process_var = tk.StringVar(value=self.processes[0])
        tk.OptionMenu(self.request_frame, self.process_var, *self.processes).grid(row=1, column=1, pady=5)

        self.request_entries = {}
        for i, resource in enumerate(self.resources):
            tk.Label(self.request_frame, text=f"Request {resource}:", fg="#f1faee", bg="#1d3557").grid(row=2+i, column=0, pady=5)
            entry = tk.Entry(self.request_frame)
            entry.grid(row=2+i, column=1, pady=5)
            self.request_entries[resource] = entry

        # Buttons
        tk.Button(self.root, text="Submit Request", font=("Showcard Gothic", 10),command=self.process_request, bg="#457b9d", fg="#f1faee").pack(pady=5)
        tk.Button(self.root, text="Hint", font=("Showcard Gothic", 10),command=self.show_hint, bg="#457b9d", fg="#f1faee").pack(pady=5)
        tk.Button(self.root, text="Back to Menu", font=("Showcard Gothic", 10),command=self.main_menu, bg="#e63946", fg="#f1faee").pack(pady=5)

    def get_resource_display(self):
        """Return formatted available resources."""
        return ", ".join(f"{r}: {self.available_resources[r]}" for r in self.resources)

    def get_allocation_display(self):
        """Return formatted current allocations."""
        display = ""
        for p in self.processes:
            allocations = ", ".join(f"{r}: {self.allocated[p][r]}" for r in self.resources)
            display += f"{p}: {allocations}\n"
        return display

    def process_request(self):
        """Handle a resource request."""
        process = self.process_var.get()
        request = {r: int(self.request_entries[r].get()) if self.request_entries[r].get().isdigit() else 0 for r in self.resources}

        # Check and allocate resources
        if all(request[r] <= self.available_resources[r] for r in self.resources):
            for r in self.resources:
                self.available_resources[r] -= request[r]
                self.allocated[process][r] += request[r]

            if self.is_safe_state():
                self.score += 10
                messagebox.showinfo("Safe State", "Request granted! +10 points!")
                if self.score >= self.level * 30:
                    self.level_up()
            else:
                messagebox.showwarning("Unsafe State", "Request leads to deadlock! Rolling back.")
                for r in self.resources:
                    self.available_resources[r] += request[r]
                    self.allocated[process][r] -= request[r]
        else:
            messagebox.showerror("Error", "Request exceeds available resources.")

        self.update_display()

    def is_safe_state(self):
        """Check for system safety."""
        work = self.available_resources.copy()
        finish = {p: False for p in self.processes}

        for _ in self.processes:
            for p in self.processes:
                if not finish[p] and all(self.max_requirements[p][r] - self.allocated[p][r] <= work[r] for r in self.resources):
                    for r in self.resources:
                        work[r] += self.allocated[p][r]
                    finish[p] = True

        return all(finish.values())

    def level_up(self):
        """Handle level progression."""
        self.level += 1
        self.score = 0
        self.setup_level()
        messagebox.showinfo("Level Up!", f"Welcome to Level {self.level}!")
        self.start_game()

    def update_display(self):
        """Update resource and allocation displays."""
        self.resource_display.config(text=self.get_resource_display())
        self.allocation_display.config(text=self.get_allocation_display())
        self.progress_bar["value"] = min(self.score / (self.level * 30) * 100, 100)

    def show_hint(self):
        """Display a hint."""
        messagebox.showinfo("Hint", "Grant requests only if they don't lead to deadlock!")


# Deadlock Block Game Code (as per your original code)
class DeadlockGame:
    def __init__(self, root, level, level_number=1):
        self.root = root
        self.level = level
        self.level_number = level_number
        self.canvas = tk.Canvas(root, width=400, height=400, bg="white")
        self.canvas.pack(padx=20, pady=20)

        self.blocks = level["blocks"]
        self.player_pos = list(level["player_start"])
        self.goals = level["goal"]
        self.walls = level["walls"]
        self.obstacles = level["obstacles"]
        self.block_ids = []
        self.wall_ids = []
        self.obstacle_ids = []
        self.time_left = 30 - (level_number - 1) * 5  # Decrease time with each level
        self.score = 0

        # Status bar area
        self.status_label = tk.Label(root, text=f"Level {self.level_number} - Time left: {self.time_left}s", font=('Arial', 12))
        self.status_label.pack(side=tk.TOP, padx=10, pady=5)

        self.draw_grid()
        self.draw_blocks()
        self.draw_walls()
        self.draw_goals()
        self.draw_player()
        self.draw_obstacles()

        self.root.bind("<Key>", self.handle_keypress)
        self.update_timer()

    def draw_grid(self):
        cell_size = 400 // 5
        for i in range(5):
            for j in range(5):
                x1, y1 = j * cell_size, i * cell_size
                x2, y2 = x1 + cell_size, y1 + cell_size
                self.canvas.create_rectangle(x1, y1, x2, y2, fill="lightgray", outline="black")

    def draw_blocks(self):
        self.block_ids = []
        cell_size = 400 // 5
        for block in self.blocks:
            x1, y1 = block[1] * cell_size, block[0] * cell_size
            x2, y2 = x1 + cell_size, y1 + cell_size
            block_id = self.canvas.create_rectangle(x1, y1, x2, y2, fill="blue", outline="black")
            self.block_ids.append(block_id)

    def draw_walls(self):
        self.wall_ids = []
        cell_size = 400 // 5
        for wall in self.walls:
            x1, y1 = wall[1] * cell_size, wall[0] * cell_size
            x2, y2 = x1 + cell_size, y1 + cell_size
            wall_id = self.canvas.create_rectangle(x1, y1, x2, y2, fill="black", outline="black")
            self.wall_ids.append(wall_id)

    def draw_goals(self):
        cell_size = 400 // 5
        for goal in self.goals:
            x1, y1 = goal[1] * cell_size, goal[0] * cell_size
            x2, y2 = x1 + cell_size, y1 + cell_size
            self.canvas.create_rectangle(x1, y1, x2, y2, fill="gold", outline="black")

    def draw_obstacles(self):
        self.obstacle_ids = []
        cell_size = 400 // 5
        for obstacle in self.obstacles:
            x1, y1 = obstacle[1] * cell_size, obstacle[0] * cell_size
            x2, y2 = x1 + cell_size, y1 + cell_size
            obstacle_id = self.canvas.create_rectangle(x1, y1, x2, y2, fill="orange", outline="black")
            self.obstacle_ids.append(obstacle_id)

    def draw_player(self):
        cell_size = 400 // 5
        x1, y1 = self.player_pos[1] * cell_size, self.player_pos[0] * cell_size
        x2, y2 = x1 + cell_size, y1 + cell_size
        self.player_id = self.canvas.create_oval(x1, y1, x2, y2, fill="red", outline="black")

    def handle_keypress(self, event):
        direction = {"Up": (-1, 0), "Down": (1, 0), "Left": (0, -1), "Right": (0, 1)}
        if event.keysym in direction:
            self.move_player(direction[event.keysym])

    def move_player(self, direction):
        new_pos = [self.player_pos[0] + direction[0], self.player_pos[1] + direction[1]]

        # Check boundaries
        if not (0 <= new_pos[0] < 5 and 0 <= new_pos[1] < 5):
            return

        # Check for walls
        if tuple(new_pos) in self.walls:
            return

        # Check for blocks
        if tuple(new_pos) in self.blocks:
            block_index = self.blocks.index(tuple(new_pos))
            block_new_pos = (
                self.blocks[block_index][0] + direction[0],
                self.blocks[block_index][1] + direction[1],
            )
            if not (0 <= block_new_pos[0] < 5 and 0 <= block_new_pos[1] < 5):
                return
            if block_new_pos in self.blocks or block_new_pos in self.walls:
                return

            self.blocks[block_index] = block_new_pos
            self.canvas.coords(
                self.block_ids[block_index],
                block_new_pos[1] * 400 // 5,
                block_new_pos[0] * 400 // 5,
                (block_new_pos[1] + 1) * 400 // 5,
                (block_new_pos[0] + 1) * 400 // 5,
            )

        # Move the player
        self.player_pos = new_pos
        self.canvas.coords(
            self.player_id,
            self.player_pos[1] * 400 // 5,
            self.player_pos[0] * 400 // 5,
            (self.player_pos[1] + 1) * 400 // 5,
            (self.player_pos[0] + 1) * 400 // 5,
        )

        # Check win condition
        if tuple(self.player_pos) in self.goals:
            self.goals.remove(tuple(self.player_pos))
            if not self.goals:
                self.level_up()

    def update_timer(self):
        if self.time_left > 0:
            self.time_left -= 1
            self.status_label.config(text=f"Level {self.level_number} - Time left: {self.time_left}s")
            self.root.after(1000, self.update_timer)
        else:
            messagebox.showerror("Time's Up!", "Game Over!")
            self.root.destroy()

    def level_up(self):
        messagebox.showinfo("Level Complete", f"You've completed Level {self.level_number}!")
        if self.level_number < len(LEVELS):
            self.level_number += 1
            self.start_new_level()
        else:
            messagebox.showinfo("Game Complete", "Congratulations! You've completed all levels!")
            self.root.destroy()

    def start_new_level(self):
        self.root.destroy()
        new_root = tk.Tk()
        game = DeadlockGame(new_root, LEVELS[self.level_number - 1], self.level_number)


if __name__ == "__main__":
    root = tk.Tk()
    game = DeadlockDetectiveGame(root)
    root.mainloop()
