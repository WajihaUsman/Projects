import tkinter as tk
from tkinter import messagebox, ttk


class DeadlockDetectiveGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Deadlock Detective Game")
        self.root.geometry("800x600")
        self.root.config(bg="#1d3557")  # Background color

        # Initialize game data
        self.level = 1
        self.score = 0
        self.setup_level()

        # Create main menu
        self.main_menu()

    def setup_level(self):
        """Set up the game level's processes, resources, and requirements."""
        base_resources = self.level + 2  # Resources grow with levels
        self.processes = [f"P{i+1}" for i in range(self.level + 2)]  # More processes per level
        self.resources = {f"R{i+1}": base_resources for i in range(3)}
        self.max_requirements = {
            p: {r: base_resources // 2 + i for i, r in enumerate(self.resources)} for p in self.processes
        }
        self.allocated = {p: {r: 0 for r in self.resources} for p in self.processes}
        self.available_resources = self.resources.copy()

    def main_menu(self):
        """Display the main menu."""
        self.clear_frame()

        tk.Label(self.root, text="Deadlock Detective", font=("Algerian", 35, "bold"), fg="#f1faee", bg="#1d3557").pack(pady=100)

        tk.Button(self.root, text="Start Game", font=("Showcard Gothic", 16), command=self.start_game, bg="#457b9d", fg="#f1faee").pack(pady=10)
        tk.Button(self.root, text="Instructions", font=("Showcard Gothic", 16), command=self.show_instructions, bg="#457b9d", fg="#f1faee").pack(pady=10)
        tk.Button(self.root, text="Quit", font=("Showcard Gothic", 16), command=self.root.quit, bg="#e63946", fg="#f1faee").pack(pady=10)

    def show_instructions(self):
        """Display game instructions."""
        messagebox.showinfo(
            "Instructions",
            "1. Allocate resources to processes without causing deadlock.\n"
            "2. Each level increases complexity.\n"
            "3. Earn points for successful requests.\n"
            "4. Reach the target score to advance levels!"
        )

    def start_game(self):
        """Start the game."""
        self.clear_frame()
        self.create_game_ui()

    def create_game_ui(self):
        """Create the game interface."""
        # Title and Progress
        tk.Label(self.root, text=f"Level {self.level}", font=("Rockwell", 18, "bold"), fg="#f1faee", bg="#1d3557").pack(pady=10)
        self.progress_bar = ttk.Progressbar(self.root, orient="horizontal", length=500, mode="determinate", maximum=100)
        self.progress_bar.pack(pady=10)

        # Display Resources
        self.resource_frame = tk.Frame(self.root, bg="#1d3557")
        self.resource_frame.pack(pady=10)
        tk.Label(self.resource_frame, text="Available Resources:", font=("Rockwell", 16, "bold"), fg="#f1faee", bg="#1d3557").grid(row=0, column=0, columnspan=2)
        self.resource_display = tk.Label(self.resource_frame, text=self.get_resource_display(), font=("Times New Roman", 12), fg="#f1faee", bg="#1d3557")
        self.resource_display.grid(row=1, column=0, columnspan=2)

        # Current Allocations
        tk.Label(self.root, text="Current Allocations:", font=("Rockwell", 16, "bold"), fg="#f1faee", bg="#1d3557").pack()
        self.allocation_display = tk.Label(self.root, text=self.get_allocation_display(), font=("Times New Roman", 12), fg="#f1faee", bg="#1d3557")
        self.allocation_display.pack()

        # Request Section
        self.request_frame = tk.Frame(self.root, bg="#1d3557")
        self.request_frame.pack(pady=20)
        tk.Label(self.request_frame, text="Submit Resource Request:", font=("Rockwell", 16, "bold"), fg="#f1faee", bg="#1d3557").grid(row=0, column=0, columnspan=2, pady=5)

        tk.Label(self.request_frame, text="Select Process:", fg="#f1faee", bg="#1d3557").grid(row=1, column=0, pady=5)
        self.process_var = tk.StringVar(value=self.processes[0])
        tk.OptionMenu(self.request_frame, self.process_var, *self.processes).grid(row=1, column=1, pady=5)

        self.request_entries = {}
        for i, resource in enumerate(self.resources):
            tk.Label(self.request_frame, text=f"Request {resource}:", fg="#f1faee", bg="#1d3557").grid(row=2+i, column=0, pady=5)
            entry = tk.Entry(self.request_frame)
            entry.grid(row=2+i, column=1, pady=5)
            self.request_entries[resource] = entry

        # Buttons
        tk.Button(self.root, text="Submit Request", font=("Showcard Gothic", 10),command=self.process_request, bg="#457b9d", fg="#f1faee").pack(pady=5)
        tk.Button(self.root, text="Hint", font=("Showcard Gothic", 10),command=self.show_hint, bg="#457b9d", fg="#f1faee").pack(pady=5)
        tk.Button(self.root, text="Back to Menu", font=("Showcard Gothic", 10),command=self.main_menu, bg="#e63946", fg="#f1faee").pack(pady=5)

    def clear_frame(self):
        """Clear the current frame."""
        for widget in self.root.winfo_children():
            widget.destroy()

    def get_resource_display(self):
        """Return formatted available resources."""
        return ", ".join(f"{r}: {self.available_resources[r]}" for r in self.resources)

    def get_allocation_display(self):
        """Return formatted current allocations."""
        display = ""
        for p in self.processes:
            allocations = ", ".join(f"{r}: {self.allocated[p][r]}" for r in self.resources)
            display += f"{p}: {allocations}\n"
        return display

    def process_request(self):
        """Handle a resource request."""
        process = self.process_var.get()
        request = {r: int(self.request_entries[r].get()) if self.request_entries[r].get().isdigit() else 0 for r in self.resources}

        # Check and allocate resources
        if all(request[r] <= self.available_resources[r] for r in self.resources):
            for r in self.resources:
                self.available_resources[r] -= request[r]
                self.allocated[process][r] += request[r]

            if self.is_safe_state():
                self.score += 10
                messagebox.showinfo("Safe State", "Request granted! +10 points!")
                if self.score >= self.level * 30:
                    self.level_up()
            else:
                messagebox.showwarning("Unsafe State", "Request leads to deadlock! Rolling back.")
                for r in self.resources:
                    self.available_resources[r] += request[r]
                    self.allocated[process][r] -= request[r]
        else:
            messagebox.showerror("Error", "Request exceeds available resources.")

        self.update_display()

    def is_safe_state(self):
        """Check for system safety."""
        work = self.available_resources.copy()
        finish = {p: False for p in self.processes}

        for _ in self.processes:
            for p in self.processes:
                if not finish[p] and all(self.max_requirements[p][r] - self.allocated[p][r] <= work[r] for r in self.resources):
                    for r in self.resources:
                        work[r] += self.allocated[p][r]
                    finish[p] = True

        return all(finish.values())

    def level_up(self):
        """Handle level progression."""
        self.level += 1
        self.score = 0
        self.setup_level()
        messagebox.showinfo("Level Up!", f"Welcome to Level {self.level}!")
        self.start_game()

    def update_display(self):
        """Update resource and allocation displays."""
        self.resource_display.config(text=self.get_resource_display())
        self.allocation_display.config(text=self.get_allocation_display())
        self.progress_bar["value"] = min(self.score / (self.level * 30) * 100, 100)

    def show_hint(self):
        """Display a hint."""
        messagebox.showinfo("Hint", "Grant requests only if they don't lead to deadlock!")

# Run the game
if __name__ == "__main__":
    root = tk.Tk()
    app = DeadlockDetectiveGame(root)
    root.mainloop()
