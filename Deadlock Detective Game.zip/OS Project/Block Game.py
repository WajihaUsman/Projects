import tkinter as tk
from tkinter import messagebox
import random

# Game Configuration for 5 Levels (More Complex Layouts)
LEVELS = [
    {"blocks": [(2, 1), (2, 2)], "player_start": (4, 0), "goal": [(0, 4)], "walls": [(1, 1), (3, 2)], "obstacles": [(1, 3)]},
    {"blocks": [(1, 1), (3, 3), (2, 4)], "player_start": (4, 0), "goal": [(0, 4), (4, 4)], "walls": [(2, 2), (1, 2)], "obstacles": [(2, 3), (3, 1)]},
    {"blocks": [(0, 1), (1, 1), (1, 2)], "player_start": (4, 0), "goal": [(0, 4)], "walls": [(2, 3)], "obstacles": [(3, 4), (0, 0)]},
    {"blocks": [(1, 1), (1, 2), (3, 1)], "player_start": (4, 0), "goal": [(0, 3), (3, 4)], "walls": [(2, 1)], "obstacles": [(0, 2), (4, 3)]},
    {"blocks": [(2, 2), (3, 3), (3, 1)], "player_start": (4, 0), "goal": [(0, 4), (4, 4)], "walls": [(2, 0), (1, 3)], "obstacles": [(3, 2), (0, 1)]},
]

class DeadlockGame:
    def __init__(self, root, level, level_number=1):
        self.root = root
        self.level = level
        self.level_number = level_number
        self.canvas = tk.Canvas(root, width=400, height=400, bg="white")
        self.canvas.pack(padx=20, pady=20)

        self.blocks = level["blocks"]
        self.player_pos = list(level["player_start"])
        self.goals = level["goal"]
        self.walls = level["walls"]
        self.obstacles = level["obstacles"]
        self.block_ids = []
        self.wall_ids = []
        self.obstacle_ids = []
        self.time_left = 30 - (level_number - 1) * 5  # Decrease time with each level
        self.score = 0

        # Status bar area
        self.status_label = tk.Label(root, text=f"Level {self.level_number} - Time left: {self.time_left}s", font=('Arial', 12))
        self.status_label.pack(side=tk.TOP, padx=10, pady=5)

        self.draw_grid()
        self.draw_blocks()
        self.draw_walls()
        self.draw_goals()
        self.draw_player()
        self.draw_obstacles()

        self.root.bind("<Key>", self.handle_keypress)
        self.update_timer()

    def draw_grid(self):
        cell_size = 400 // 5
        for i in range(5):
            for j in range(5):
                x1, y1 = j * cell_size, i * cell_size
                x2, y2 = x1 + cell_size, y1 + cell_size
                self.canvas.create_rectangle(x1, y1, x2, y2, fill="lightgray", outline="black")

    def draw_blocks(self):
        self.block_ids = []
        cell_size = 400 // 5
        for block in self.blocks:
            x1, y1 = block[1] * cell_size, block[0] * cell_size
            x2, y2 = x1 + cell_size, y1 + cell_size
            block_id = self.canvas.create_rectangle(x1, y1, x2, y2, fill="blue", outline="black")
            self.block_ids.append(block_id)

    def draw_walls(self):
        self.wall_ids = []
        cell_size = 400 // 5
        for wall in self.walls:
            x1, y1 = wall[1] * cell_size, wall[0] * cell_size
            x2, y2 = x1 + cell_size, y1 + cell_size
            wall_id = self.canvas.create_rectangle(x1, y1, x2, y2, fill="black", outline="black")
            self.wall_ids.append(wall_id)

    def draw_goals(self):
        cell_size = 400 // 5
        for goal in self.goals:
            x1, y1 = goal[1] * cell_size, goal[0] * cell_size
            x2, y2 = x1 + cell_size, y1 + cell_size
            self.canvas.create_rectangle(x1, y1, x2, y2, fill="gold", outline="black")

    def draw_obstacles(self):
        self.obstacle_ids = []
        cell_size = 400 // 5
        for obstacle in self.obstacles:
            x1, y1 = obstacle[1] * cell_size, obstacle[0] * cell_size
            x2, y2 = x1 + cell_size, y1 + cell_size
            obstacle_id = self.canvas.create_rectangle(x1, y1, x2, y2, fill="orange", outline="black")
            self.obstacle_ids.append(obstacle_id)

    def draw_player(self):
        cell_size = 400 // 5
        x1, y1 = self.player_pos[1] * cell_size, self.player_pos[0] * cell_size
        x2, y2 = x1 + cell_size, y1 + cell_size
        self.player_id = self.canvas.create_oval(x1, y1, x2, y2, fill="red", outline="black")

    def handle_keypress(self, event):
        direction = {"Up": (-1, 0), "Down": (1, 0), "Left": (0, -1), "Right": (0, 1)}
        if event.keysym in direction:
            self.move_player(direction[event.keysym])

    def move_player(self, direction):
        new_pos = [self.player_pos[0] + direction[0], self.player_pos[1] + direction[1]]

        # Check boundaries
        if not (0 <= new_pos[0] < 5 and 0 <= new_pos[1] < 5):
            return

        # Check for walls
        if tuple(new_pos) in self.walls:
            return

        # Check for blocks
        if tuple(new_pos) in self.blocks:
            block_index = self.blocks.index(tuple(new_pos))
            block_new_pos = (
                self.blocks[block_index][0] + direction[0],
                self.blocks[block_index][1] + direction[1],
            )
            if not (0 <= block_new_pos[0] < 5 and 0 <= block_new_pos[1] < 5):
                return
            if block_new_pos in self.blocks or block_new_pos in self.walls:
                return

            self.blocks[block_index] = block_new_pos
            self.canvas.coords(
                self.block_ids[block_index],
                block_new_pos[1] * 400 // 5,
                block_new_pos[0] * 400 // 5,
                (block_new_pos[1] + 1) * 400 // 5,
                (block_new_pos[0] + 1) * 400 // 5,
            )

        # Move the player
        self.player_pos = new_pos
        self.canvas.coords(
            self.player_id,
            self.player_pos[1] * 400 // 5,
            self.player_pos[0] * 400 // 5,
            (self.player_pos[1] + 1) * 400 // 5,
            (self.player_pos[0] + 1) * 400 // 5,
        )

        # Check win condition
        if tuple(self.player_pos) in self.goals:
            self.goals.remove(tuple(self.player_pos))
            if not self.goals:
                self.level_up()

    def update_timer(self):
        if self.time_left > 0:
            self.time_left -= 1
            self.status_label.config(text=f"Level {self.level_number} - Time left: {self.time_left}s")
            self.root.after(1000, self.update_timer)
        else:
            messagebox.showerror("Time's Up!", "Game Over!")
            self.root.destroy()

    def level_up(self):
        messagebox.showinfo("Level Complete", f"You've completed Level {self.level_number}!")
        if self.level_number < len(LEVELS):
            self.level_number += 1
            self.start_new_level()
        else:
            messagebox.showinfo("Game Complete", "Congratulations! You've completed all levels!")
            self.root.destroy()

    def start_new_level(self):
        self.root.destroy()
        new_root = tk.Tk()
        game = DeadlockGame(new_root, LEVELS[self.level_number - 1], self.level_number)

def main_menu():
    root = tk.Tk()
    root.title("Deadlock Game Menu")
    root.geometry("400x300")

    tk.Label(root, text="Welcome to the Deadlock Game", font=('Arial', 18)).pack(pady=20)

    tk.Button(root, text="Start Game", command=lambda: start_game(root)).pack(pady=10)
    tk.Button(root, text="Quit", command=root.quit).pack(pady=10)

    root.mainloop()

def start_game(root):
    root.destroy()
    new_root = tk.Tk()
    game = DeadlockGame(new_root, LEVELS[0])

if __name__ == "__main__":
    main_menu()
