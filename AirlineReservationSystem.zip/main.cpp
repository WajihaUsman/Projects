#include <iostream>
#include <string>

using namespace std;

struct Flight {
    string flightDate;
    string flightTime;
    string flightDay;
    string departure;
    string destination;
    bool available;
};

struct Passenger {
    string name;
    bool reserved;
    string flightDate;
    string flightTime;
    string flightDay;
    string departure;
    string destination;
};

const int MAX_FLIGHTS = 100;
const int MAX_PASSENGERS = 100;

Flight flights[MAX_FLIGHTS];
Passenger passengers[MAX_PASSENGERS];

int numFlights = 0;
int numPassengers = 0;

void makeReservation() {
    string name;
    cout << "Enter passenger name: ";
    cin.ignore();
    getline(cin, name);

    string flightDate;
    cout << "Enter flight date: ";
    getline(cin, flightDate);

    string flightTime;
    cout << "Enter flight time: ";
    getline(cin, flightTime);

    string flightDay;
    cout << "Enter flight day: ";
    getline(cin, flightDay);
    
    string departure;
    cout << "From: ";
    getline(cin, departure);

    string destination;
    cout << "To: ";
    getline(cin, destination);
  

    bool flightAvailable = false;
    for (int i = 0; i < numFlights; i++) {
        if (flights[i].flightDate == flightDate && flights[i].flightDay == flightDay && flights[i].flightTime == flightTime) {
            flightAvailable = flights[i].available;
            break;
        }
    }

    if (flightAvailable) {
        Passenger passenger;
        passenger.name = name;
        passenger.reserved = true;
        passenger.flightDate = flightDate;
        passenger.flightTime = flightTime;
        passenger.flightDay = flightDay;
        passenger.departure = departure;
        passenger.destination = destination;
        passengers[numPassengers++] = passenger;

        cout << "Reservation made successfully!" << endl;
    } else {
        cout << "Sorry, the flight is not available on the specified date, day, and time." << endl;
    }
}

void cancelReservation() {
    string name;
    cout << "Enter passenger name: ";
    cin.ignore();
    getline(cin, name);

    bool found = false;
    for (int i = 0; i < numPassengers; i++) {
        if (passengers[i].name == name && passengers[i].reserved) {
            passengers[i].reserved = false;
            found = true;
            cout << "Reservation canceled successfully!" << endl;
            break;
        }
    }

    if (!found) {
        cout << "Passenger not found or has no reservation." << endl;
    }
}

void searchPassenger() {
    string name;
    cout << "Enter passenger name: ";
    cin.ignore();
    getline(cin, name);

    bool found = false;
    for (int i = 0; i < numPassengers; i++) {
        if (passengers[i].name == name) {
            found = true;
            cout << "Passenger: " << passengers[i].name << endl;
            cout << "Reservation Status: " << (passengers[i].reserved ? "Reserved" : "Not Reserved") << endl;
            cout << "Flight Date: " << passengers[i].flightDate << endl;
            cout << "Flight Time: " << passengers[i].flightTime << endl;
            cout << "Flight Day: " << passengers[i].flightDay << endl;
            cout << "From: " << passengers[i].departure << endl;
            cout << "To: " << passengers[i].destination << endl;
            break;
        }
    }

    if (!found) {
        cout << "Passenger not found." << endl;
    }
}

void printStatusReport() {
    cout << "Passenger List and Status Report:" << endl;
    for (int i = 0; i < numPassengers; i++) {
        cout << "Passenger: " << passengers[i].name << endl;
        cout << "Reservation Status: " << (passengers[i].reserved ? "Reserved" : "Not Reserved") << endl;
        cout << "Flight Date: " << passengers[i].flightDate << endl;
        cout << "Flight Time: " << passengers[i].flightTime << endl;
        cout << "Flight Day: " << passengers[i].flightDay << endl;
        cout << "From: " << passengers[i].departure << endl;
        cout << "To: " << passengers[i].destination << endl;
        cout << endl;
    }
}

int main() 
{
    
    flights[numFlights++] = {"2023-06-05", "10:00", "Monday", "New York", "Los Angeles", true};
    flights[numFlights++] = {"2023-06-06", "15:30", "Tuesday", "Chicago", "Miami", false};
    flights[numFlights++] = {"2023-06-07", "09:45", "Wednesday", "London", "Paris", true};

    int choice;
    bool quit = false;

    cout<<"**********WELCOME TO AIRLINE RESERVATION SYSTEM**********"<<endl;
    cout<<endl;
    
    while (!quit) {
        cout << "Airline Reservation System" << endl;
        cout << "1. Make Reservation" << endl;
        cout << "2. Cancel Reservation" << endl;
        cout << "3. Search Passenger" << endl;
        cout << "4. Print Status Report" << endl;
        cout << "5. Quit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                makeReservation();
                break;
            case 2:
                cancelReservation();
                break;
            case 3:
                searchPassenger();
                break;
            case 4:
                printStatusReport();
                break;
            case 5:
                quit = true;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
                break;
        }

        cout << endl;
    }

    return 0;
}

