import React, { useState, useEffect } from 'react';

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalSuppliers: 0,
    totalWarehouses: 0,
    totalInventory: 0,
    pendingOrders: 0,
    activeShipments: 0,
    totalRevenue: 0,
    monthlyGrowth: 0
  });

  const [recentOrders, setRecentOrders] = useState([]);
  const [lowStockItems, setLowStockItems] = useState([]);

  useEffect(() => {
    // Fetch real data from backend API
    fetchStats();
    fetchRecentOrders();
    fetchLowStockItems();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('http://localhost:3004/api/analytics');
      const data = await response.json();
      setStats(data.stats);
    } catch (error) {
      console.error('Error fetching stats:', error);
      // Fallback to mock data
      setStats({
        totalProducts: 120,
        totalSuppliers: 25,
        totalWarehouses: 8,
        totalInventory: 15420,
        pendingOrders: 12,
        activeShipments: 8,
        totalRevenue: 2450000,
        monthlyGrowth: 15.3
      });
    }
  };

  const fetchRecentOrders = async () => {
    try {
      const response = await fetch('http://localhost:3004/api/orders');
      const data = await response.json();
      setRecentOrders(data.recentOrders || data);
    } catch (error) {
      console.error('Error fetching recent orders:', error);
      // Fallback to mock data
      setRecentOrders([
        { id: 1001, customer: 'Ahmed Hassan', product: 'Mouse', quantity: 3, status: 'Delivered', date: '2026-05-08' },
        { id: 1002, customer: 'Sara Khan', product: 'Keyboard', quantity: 2, status: 'Pending', date: '2026-05-07' },
        { id: 1003, customer: 'Ali Raza', product: 'Monitor', quantity: 1, status: 'Shipped', date: '2026-05-06' },
        { id: 1004, customer: 'Fatima Noor', product: 'Mouse', quantity: 5, status: 'Processing', date: '2026-05-05' },
      ]);
    }
  };

  const fetchLowStockItems = async () => {
    try {
      const response = await fetch('http://localhost:3004/api/inventory');
      const data = await response.json();
      setLowStockItems(data.lowStock || data);
    } catch (error) {
      console.error('Error fetching low stock items:', error);
      // Fallback to mock data
      setLowStockItems([
        { id: 100, name: 'Wireless Mouse', currentStock: 5, minStock: 10 },
        { id: 101, name: 'USB Keyboard', currentStock: 8, minStock: 15 },
        { id: 102, name: 'Webcam HD', currentStock: 3, minStock: 8 },
      ]);
    }
  };

  const StatCard = ({ title, value, change, changeType, color = 'blue' }) => (
    <div className="stat-card">
      <div className="stat-value" style={{ color: color === 'green' ? '#28a745' : color === 'orange' ? '#ffc107' : '#007bff' }}>
        {value}
      </div>
      <div className="stat-label">{title}</div>
      {change && (
        <div style={{ fontSize: '0.875rem', color: changeType === 'increase' ? '#28a745' : '#dc3545' }}>
          {changeType === 'increase' ? '↑' : '↓'} {change}
        </div>
      )}
    </div>
  );

  return (
    <div>
      <h1>Dashboard</h1>
      <p>Welcome to SupplyHub Management System</p>

      {/* Stats Grid */}
      <div className="stats-grid">
        <StatCard
          title="Total Products"
          value={stats.totalProducts}
        />
        <StatCard
          title="Total Suppliers"
          value={stats.totalSuppliers}
        />
        <StatCard
          title="Warehouses"
          value={stats.totalWarehouses}
        />
        <StatCard
          title="Total Inventory"
          value={stats.totalInventory ? stats.totalInventory.toLocaleString() : '0'}
        />
        <StatCard
          title="Pending Orders"
          value={stats.pendingOrders}
        />
        <StatCard
          title="Active Shipments"
          value={stats.activeShipments}
        />
        <StatCard
          title="Total Revenue"
          value={`PKR ${stats.totalRevenue ? stats.totalRevenue.toLocaleString() : '0'}`}
          change="+12.5%"
          changeType="increase"
          color="green"
        />
        <StatCard
          title="Monthly Growth"
          value={`${stats.monthlyGrowth || 0}%`}
          changeType="increase"
          color="green"
        />
      </div>

      <div>
        {/* Recent Orders */}
        <div>
          <h3>Recent Orders</h3>
          <table className="table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Product</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((order) => (
                <tr key={order.id}>
                  <td>#{order.id}</td>
                  <td>{order.customer}</td>
                  <td>{order.product}</td>
                  <td>
                    <span className={`badge badge-${order.status === 'Delivered' ? 'success' : order.status === 'Pending' ? 'warning' : order.status === 'Shipped' ? 'info' : 'info'}`}>
                      {order.status}
                    </span>
                  </td>
                  <td>{order.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>

        {/* Low Stock Alert */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Low Stock Alert</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Current Stock</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Min Stock</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {lowStockItems.map((item) => (
                  <tr key={item.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.currentStock}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.minStock}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                        Critical
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
  );
};

export default Dashboard;
