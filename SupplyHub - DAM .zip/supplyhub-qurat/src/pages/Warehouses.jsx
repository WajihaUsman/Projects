import React, { useState, useEffect } from 'react';
import DataTable from '../components/Common/DataTable';
import Modal from '../components/Common/Modal';
import FormField from '../components/Common/FormField';

const Warehouses = () => {
  const [warehouses, setWarehouses] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingWarehouse, setEditingWarehouse] = useState(null);
  const [formData, setFormData] = useState({
    WAREHOUSE_NAME: '',
    CITY: ''
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    // Fetch real data from backend API
    fetchWarehouses();
  }, []);

  const fetchWarehouses = async () => {
    try {
      const response = await fetch('http://localhost:3004/api/warehouses');
      const data = await response.json();
      setWarehouses(data);
    } catch (error) {
      console.error('Error fetching warehouses:', error);
      // Fallback to mock data if API fails
      setWarehouses([
        { WAREHOUSE_ID: 1, WAREHOUSE_NAME: 'Karachi Main', LOCATION: 'Karachi, Pakistan', CAPACITY: 10000, MANAGER: 'Ahmed Hassan', PHONE: '+92-21-1234567' },
        { WAREHOUSE_ID: 2, WAREHOUSE_NAME: 'Lahore Branch', LOCATION: 'Lahore, Pakistan', CAPACITY: 8000, MANAGER: 'Sara Khan', PHONE: '+92-42-7654321' },
        { WAREHOUSE_ID: 3, WAREHOUSE_NAME: 'Islamabad Hub', LOCATION: 'Islamabad, Pakistan', CAPACITY: 6000, MANAGER: 'Ali Raza', PHONE: '+92-51-9876543' },
      ]);
    }
  };

  const handleAdd = () => {
    setEditingWarehouse(null);
    setFormData({
      WAREHOUSE_NAME: '',
      CITY: ''
    });
    setErrors({});
    setIsModalOpen(true);
  };

  const handleEdit = (warehouse) => {
    console.log('Edit button clicked for warehouse:', warehouse);
    console.log('Warehouse ID:', warehouse.WAREHOUSE_ID || warehouse.warehouse_id);
    console.log('Warehouse Name:', warehouse.WAREHOUSE_NAME || warehouse.name);
    console.log('Warehouse City:', warehouse.CITY || warehouse.location);
    setEditingWarehouse(warehouse);
    setFormData({
      WAREHOUSE_NAME: warehouse.WAREHOUSE_NAME || warehouse.name,
      CITY: warehouse.CITY || warehouse.location
    });
    setErrors({});
    setIsModalOpen(true);
  };

  const handleDelete = async (warehouse) => {
    console.log('Delete button clicked for warehouse:', warehouse);
    console.log('Warehouse ID:', warehouse.WAREHOUSE_ID || warehouse.warehouse_id);
    console.log('Warehouse Name:', warehouse.WAREHOUSE_NAME || warehouse.name);
    if (window.confirm(`Are you sure you want to delete ${warehouse.WAREHOUSE_NAME || warehouse.name}?`)) {
      try {
        // API call to delete warehouse
        const response = await fetch(`http://localhost:3004/api/warehouses/${warehouse.WAREHOUSE_ID || warehouse.warehouse_id}`, {
          method: 'DELETE'
        });
        
        if (response.ok) {
          // Refresh warehouses list
          fetchWarehouses();
        } else {
          console.error('Failed to delete warehouse');
        }
      } catch (error) {
        console.error('Error deleting warehouse:', error);
      }
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.WAREHOUSE_NAME.trim()) newErrors.WAREHOUSE_NAME = 'Warehouse name is required';
    if (!formData.CITY.trim()) newErrors.CITY = 'Location is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      if (editingWarehouse) {
        // API call to update warehouse
        console.log('Updating warehouse:', editingWarehouse.WAREHOUSE_ID || editingWarehouse.warehouse_id, formData);
        const warehouseData = {
          warehouse_name: formData.WAREHOUSE_NAME,
          city: formData.CITY
        };
        
        const response = await fetch(`http://localhost:3004/api/warehouses/${editingWarehouse.WAREHOUSE_ID || editingWarehouse.warehouse_id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(warehouseData)
        });
        
        if (response.ok) {
          // Refresh warehouses list
          fetchWarehouses();
        } else {
          console.error('Failed to update warehouse');
        }
      } else {
        // API call to create warehouse
        console.log('Creating warehouse:', formData);
        const warehouseData = {
          warehouse_name: formData.WAREHOUSE_NAME,
          city: formData.CITY
        };
        
        const response = await fetch('http://localhost:3004/api/warehouses', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(warehouseData)
        });
        
        if (response.ok) {
          // Refresh warehouses list
          fetchWarehouses();
        } else {
          console.error('Failed to create warehouse');
        }
      }
      setIsModalOpen(false);
      setEditingWarehouse(null);
    } catch (error) {
      console.error('Error saving warehouse:', error);
    }
  };

  const columns = [
    { key: 'WAREHOUSE_ID', label: 'ID' },
    { key: 'WAREHOUSE_NAME', label: 'Warehouse Name' },
    { key: 'CITY', label: 'Location' }
  ];

  return (
    <div>
      <h1>Warehouses</h1>
      <p>Manage your warehouse locations</p>
      
      <DataTable
        data={warehouses}
        columns={columns}
        title="Warehouses"
        onAdd={handleAdd}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingWarehouse ? 'Edit Warehouse' : 'Add Warehouse'}
      >
        <form onSubmit={handleSubmit}>
          <FormField
            label="Warehouse Name"
            name="WAREHOUSE_NAME"
            type="text"
            value={formData.WAREHOUSE_NAME}
            onChange={(e) => setFormData({ ...formData, WAREHOUSE_NAME: e.target.value })}
            error={errors.WAREHOUSE_NAME}
            required
          />
          <FormField
            label="Location"
            name="CITY"
            type="text"
            value={formData.CITY}
            onChange={(e) => setFormData({ ...formData, CITY: e.target.value })}
            error={errors.CITY}
            required
          />
                    <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="btn btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
            >
              {editingWarehouse ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Warehouses;
