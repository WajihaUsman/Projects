import React, { useState, useEffect } from 'react';
import DataTable from '../components/Common/DataTable';
import Modal from '../components/Common/Modal';
import FormField from '../components/Common/FormField';

const Suppliers = () => {
  const [suppliers, setSuppliers] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [formData, setFormData] = useState({
    SUPPLIER_NAME: '',
    CONTACT_NO: '',
    PRODUCTS: []
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    // Fetch real data from backend API
    fetchSuppliers();
  }, []);

  const fetchSuppliers = async () => {
    try {
      const response = await fetch('http://localhost:3004/api/suppliers');
      const data = await response.json();
      setSuppliers(data);
    } catch (error) {
      console.error('Error fetching suppliers:', error);
      // Fallback to mock data if API fails
      setSuppliers([
        { supplier_id: 1, name: 'Tech Supplies Inc.', contact_person: 'John Smith', email: 'john@techsupplies.com', phone: '+92-21-1234567', address: '123 Main St', city: 'Karachi', country: 'Pakistan' },
        { supplier_id: 2, name: 'Computer Parts Co.', contact_person: 'Sarah Ahmed', email: 'sarah@computerparts.com', phone: '+92-21-7654321', address: '456 Oak Ave', city: 'Lahore', country: 'Pakistan' },
        { supplier_id: 3, name: 'Electronics World', contact_person: 'Ali Khan', email: 'ali@electronicsworld.com', phone: '+92-21-9876543', address: '789 Pine Rd', city: 'Islamabad', country: 'Pakistan' },
      ]);
    }
  };

  const handleAdd = () => {
    setEditingSupplier(null);
    setFormData({
      SUPPLIER_NAME: '',
      CONTACT_NO: '',
      PRODUCTS: []
    });
    setErrors({});
    setIsModalOpen(true);
  };

  const handleEdit = (supplier) => {
    console.log('Edit button clicked for supplier:', supplier);
    setEditingSupplier(supplier);
    setFormData({
      SUPPLIER_NAME: supplier.SUPPLIER_NAME || supplier.name,
      CONTACT_NO: supplier.CONTACT_NO || supplier.phone,
      PRODUCTS: supplier.PRODUCTS || []
    });
    setErrors({});
    setIsModalOpen(true);
  };

  const handleDelete = async (supplier) => {
    console.log('Delete button clicked for supplier:', supplier);
    console.log('Supplier ID:', supplier.SUPPLIER_ID || supplier.supplier_id);
    console.log('Supplier Name:', supplier.SUPPLIER_NAME || supplier.name);
    if (window.confirm(`Are you sure you want to delete ${supplier.SUPPLIER_NAME || supplier.name}?`)) {
      try {
        // API call to delete supplier
        const response = await fetch(`http://localhost:3004/api/suppliers/${supplier.SUPPLIER_ID || supplier.supplier_id}`, {
          method: 'DELETE'
        });
        
        if (response.ok) {
          // Refresh suppliers list
          fetchSuppliers();
        } else {
          console.error('Failed to delete supplier');
        }
      } catch (error) {
        console.error('Error deleting supplier:', error);
      }
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.SUPPLIER_NAME.trim()) newErrors.SUPPLIER_NAME = 'Supplier name is required';
    if (!formData.CONTACT_NO.trim()) newErrors.CONTACT_NO = 'Phone is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      if (editingSupplier) {
        // API call to update supplier
        console.log('Updating supplier:', editingSupplier.SUPPLIER_ID || editingSupplier.supplier_id, formData);
        const supplierData = {
          supplier_name: formData.SUPPLIER_NAME,
          contact_no: formData.CONTACT_NO,
          city: 'Default City' // Backend expects city field
        };
        
        const response = await fetch(`http://localhost:3004/api/suppliers/${editingSupplier.SUPPLIER_ID || editingSupplier.supplier_id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(supplierData)
        });
        
        if (response.ok) {
          // Refresh suppliers list
          fetchSuppliers();
        } else {
          console.error('Failed to update supplier');
        }
      } else {
        // API call to create supplier
        console.log('Creating supplier:', formData);
        const supplierData = {
          supplier_name: formData.SUPPLIER_NAME,
          contact_no: formData.CONTACT_NO,
          city: 'Default City' // Backend expects city field
        };
        
        const response = await fetch('http://localhost:3004/api/suppliers', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(supplierData)
        });
        
        if (response.ok) {
          // Refresh suppliers list
          fetchSuppliers();
        } else {
          console.error('Failed to create supplier');
        }
      }
      setIsModalOpen(false);
      setEditingSupplier(null);
    } catch (error) {
      console.error('Error saving supplier:', error);
    }
  };

  const columns = [
    { key: 'SUPPLIER_ID', label: 'ID' },
    { key: 'SUPPLIER_NAME', label: 'Supplier Name' },
    { key: 'CONTACT_NO', label: 'Phone' },
    { key: 'PRODUCTS', label: 'Products', render: (value, row) => {
      // Show products supplied by this supplier
      if (row.PRODUCTS && row.PRODUCTS.length > 0) {
        return (
          <div>
            {row.PRODUCTS.map((product, index) => (
              <div key={index} style={{ padding: '0.25rem', borderBottom: '1px solid #eee' }}>
                <strong>{product.PRODUCT_NAME}</strong> - {product.QUANTITY} units @ PKR {product.PRICE}
              </div>
            ))}
          </div>
        );
      }
      return <span style={{ color: '#999' }}>No products</span>;
    }}
  ];

  return (
    <div>
      <h1>Suppliers</h1>
      <p>Manage your supplier information</p>
      
      <DataTable
        data={suppliers}
        columns={columns}
        title="Suppliers"
        onAdd={handleAdd}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingSupplier ? 'Edit Supplier' : 'Add Supplier'}
      >
        <form onSubmit={handleSubmit}>
          <FormField
            label="Supplier Name*"
            name="SUPPLIER_NAME"
            type="text"
            value={formData.SUPPLIER_NAME}
            onChange={(e) => setFormData({ ...formData, SUPPLIER_NAME: e.target.value })}
            error={errors.SUPPLIER_NAME}
            required
          />
          <FormField
            label="Phone*"
            name="CONTACT_NO"
            type="text"
            value={formData.CONTACT_NO}
            onChange={(e) => setFormData({ ...formData, CONTACT_NO: e.target.value })}
            error={errors.CONTACT_NO}
            required
          />
          
          {/* Product Management Section */}
          <div style={{ marginTop: '1rem', padding: '1rem', border: '1px solid #ddd', borderRadius: '4px' }}>
            <h4 style={{ marginBottom: '0.5rem' }}>Products Supplied</h4>
            <div style={{ marginBottom: '1rem' }}>
              <FormField
                label="Product Name"
                type="text"
                value={formData.newProduct?.PRODUCT_NAME || ''}
                onChange={(e) => setFormData({ 
                  ...formData, 
                  newProduct: { ...formData.newProduct, PRODUCT_NAME: e.target.value }
                })}
              />
              <FormField
                label="Quantity"
                type="number"
                value={formData.newProduct?.QUANTITY || ''}
                onChange={(e) => setFormData({ 
                  ...formData, 
                  newProduct: { ...formData.newProduct, QUANTITY: e.target.value }
                })}
              />
              <FormField
                label="Price"
                type="number"
                value={formData.newProduct?.PRICE || ''}
                onChange={(e) => setFormData({ 
                  ...formData, 
                  newProduct: { ...formData.newProduct, PRICE: e.target.value }
                })}
              />
              <button
                type="button"
                onClick={() => {
                  if (formData.newProduct?.PRODUCT_NAME && formData.newProduct?.QUANTITY && formData.newProduct?.PRICE) {
                    setFormData({
                      ...formData,
                      PRODUCTS: [...formData.PRODUCTS, formData.newProduct],
                      newProduct: { PRODUCT_NAME: '', QUANTITY: '', PRICE: '' }
                    });
                  }
                }}
                className="btn btn-secondary"
                style={{ marginTop: '0.5rem' }}
              >
                Add Product
              </button>
            </div>
            
            {/* Products List */}
            {formData.PRODUCTS && formData.PRODUCTS.length > 0 && (
              <div style={{ marginTop: '1rem' }}>
                <h5 style={{ marginBottom: '0.5rem' }}>Current Products</h5>
                {formData.PRODUCTS.map((product, index) => (
                  <div key={index} style={{ 
                    padding: '0.5rem', 
                    border: '1px solid #eee', 
                    borderRadius: '4px', 
                    marginBottom: '0.5rem',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                    <div>
                      <strong>{product.PRODUCT_NAME}</strong>
                      <br />
                      <small>Qty: {product.QUANTITY} | Price: PKR {product.PRICE}</small>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const updatedProducts = formData.PRODUCTS.filter((_, i) => i !== index);
                        setFormData({
                          ...formData,
                          PRODUCTS: updatedProducts
                        });
                      }}
                      className="btn btn-sm btn-danger"
                      style={{ padding: '0.25rem 0.5rem' }}
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="btn btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
            >
              {editingSupplier ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Suppliers;
