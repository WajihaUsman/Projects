import React, { useState, useEffect } from 'react';
import DataTable from '../components/Common/DataTable';
import Modal from '../components/Common/Modal';
import FormField from '../components/Common/FormField';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState(null);
  const [formData, setFormData] = useState({
    CUSTOMER_NAME: '',
    PRODUCT_ID: '',
    QUANTITY: '',
    ORDER_DATE: '',
    STATUS: 'Pending'
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    // Fetch real data from backend APIs
    fetchOrders();
    fetchProducts();
  }, []);

  const fetchOrders = async () => {
    try {
      const response = await fetch('http://localhost:3004/api/orders');
      const data = await response.json();
      setOrders(data);
    } catch (error) {
      console.error('Error fetching orders:', error);
      // Fallback to mock data if API fails
      setOrders([
        { ORDER_ID: 1, CUSTOMER_NAME: 'John Doe', PRODUCT_ID: 100, QUANTITY: 2, ORDER_DATE: '2024-01-15', STATUS: 'Delivered' },
        { ORDER_ID: 2, CUSTOMER_NAME: 'Jane Smith', PRODUCT_ID: 120, QUANTITY: 1, ORDER_DATE: '2024-01-16', STATUS: 'Pending' },
        { ORDER_ID: 3, CUSTOMER_NAME: 'Bob Johnson', PRODUCT_ID: 100, QUANTITY: 3, ORDER_DATE: '2024-01-17', STATUS: 'Processing' },
        { ORDER_ID: 4, CUSTOMER_NAME: 'Alice Brown', PRODUCT_ID: 120, QUANTITY: 1, ORDER_DATE: '2024-01-18', STATUS: 'Shipped' },
      ]);
    }
  };

  const fetchProducts = async () => {
    try {
      const response = await fetch('http://localhost:3004/api/products');
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
      // Fallback to mock data if API fails
      setProducts([
        { PRODUCT_ID: 100, PRODUCT_NAME: 'mouse' },
        { PRODUCT_ID: 120, PRODUCT_NAME: 'mouse no2' },
      ]);
    }
  };

  const handleAdd = () => {
    setEditingOrder(null);
    setFormData({
      CUSTOMER_NAME: '',
      PRODUCT_ID: '',
      QUANTITY: '',
      ORDER_DATE: new Date().toISOString().split('T')[0],
      STATUS: 'Pending'
    });
    setErrors({});
    setIsModalOpen(true);
  };

  const handleEdit = (order) => {
    setEditingOrder(order);
    setFormData({
      CUSTOMER_NAME: order.CUSTOMER_NAME || order.customer_name,
      PRODUCT_ID: (order.PRODUCT_ID || order.product_id).toString(),
      QUANTITY: (order.QUANTITY || order.quantity).toString(),
      ORDER_DATE: order.ORDER_DATE || order.order_date,
      STATUS: order.STATUS || order.status
    });
    setErrors({});
    setIsModalOpen(true);
  };

  const handleDelete = async (order) => {
    console.log('Delete button clicked for order:', order);
    console.log('Order ID:', order.ORDER_ID || order.order_id);
    if (window.confirm(`Are you sure you want to delete order #${order.ORDER_ID || order.order_id}?`)) {
      try {
        // API call to delete order
        const response = await fetch(`http://localhost:3004/api/orders/${order.ORDER_ID || order.order_id}`, {
          method: 'DELETE'
        });
        
        if (response.ok) {
          // Refresh orders list
          fetchOrders();
        } else {
          console.error('Failed to delete order');
        }
      } catch (error) {
        console.error('Error deleting order:', error);
      }
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.CUSTOMER_NAME.trim()) newErrors.CUSTOMER_NAME = 'Customer name is required';
    if (!formData.PRODUCT_ID) newErrors.PRODUCT_ID = 'Product is required';
    if (!formData.QUANTITY || formData.QUANTITY <= 0) newErrors.QUANTITY = 'Quantity must be greater than 0';
    if (!formData.ORDER_DATE) newErrors.ORDER_DATE = 'Order date is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      if (editingOrder) {
        // API call to update order
        console.log('Updating order:', editingOrder.ORDER_ID || editingOrder.order_id, formData);
        const orderData = {
          customer_name: formData.CUSTOMER_NAME,
          product_id: parseInt(formData.PRODUCT_ID),
          quantity: parseInt(formData.QUANTITY),
          order_date: formData.ORDER_DATE?.split('T')[0] || formData.ORDER_DATE,
          status: formData.STATUS
        };
        
        const response = await fetch(`http://localhost:3004/api/orders/${editingOrder.ORDER_ID || editingOrder.order_id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
          // Refresh orders list
          fetchOrders();
        } else {
          console.error('Failed to update order');
        }
      } else {
        // API call to create order
        console.log('Creating order:', formData);
        const orderData = {
          customer_name: formData.CUSTOMER_NAME,
          product_id: parseInt(formData.PRODUCT_ID),
          quantity: parseInt(formData.QUANTITY),
          order_date: formData.ORDER_DATE?.split('T')[0] || formData.ORDER_DATE,
          status: formData.STATUS
        };
        
        const response = await fetch('http://localhost:3004/api/orders', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(orderData)
        });
        
        if (response.ok) {
          // Refresh orders list
          fetchOrders();
        } else {
          console.error('Failed to create order');
        }
      }
      setIsModalOpen(false);
      setEditingOrder(null);
    } catch (error) {
      console.error('Error saving order:', error);
    }
  };

  const getStatusClass = (status) => {
    switch (status) {
      case 'Delivered': return 'badge-success';
      case 'Pending': return 'badge-warning';
      case 'Processing': return 'badge-info';
      case 'Shipped': return 'badge-info';
      default: return 'badge-info';
    }
  };

  const columns = [
    { key: 'ORDER_ID', label: 'Order ID' },
    { key: 'CUSTOMER_NAME', label: 'Customer' },
    { key: 'PRODUCT_ID', label: 'Product', render: (value) => {
      const product = products.find(p => p.PRODUCT_ID === value);
      return product ? product.PRODUCT_NAME || product.product_name : 'Unknown';
    }},
    { key: 'QUANTITY', label: 'Quantity' },
    { key: 'ORDER_DATE', label: 'Order Date' },
    { key: 'STATUS', label: 'Status', render: (value) => 
      <span className={`badge ${getStatusClass(value)}`}>{value}</span>
    }
  ];

  return (
    <div>
      <h1>Order Management</h1>
      <p>Process and track customer orders</p>
      
      <DataTable
        data={orders}
        columns={columns}
        title="Orders"
        onAdd={handleAdd}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingOrder ? 'Edit Order' : 'Add Order'}
      >
        <form onSubmit={handleSubmit}>
          <FormField
            label="Customer Name"
            name="CUSTOMER_NAME"
            type="text"
            value={formData.CUSTOMER_NAME}
            onChange={(e) => setFormData({ ...formData, CUSTOMER_NAME: e.target.value })}
            error={errors.CUSTOMER_NAME}
            required
          />
          <FormField
            label="Product"
            name="PRODUCT_ID"
            type="select"
            value={formData.PRODUCT_ID}
            onChange={(e) => setFormData({ ...formData, PRODUCT_ID: e.target.value })}
            error={errors.PRODUCT_ID}
            options={products.map(p => ({ value: (p.PRODUCT_ID || p.product_id).toString(), label: p.PRODUCT_NAME || p.product_name }))}
            required
          />
          <FormField
            label="Quantity"
            name="QUANTITY"
            type="number"
            value={formData.QUANTITY}
            onChange={(e) => setFormData({ ...formData, QUANTITY: e.target.value })}
            error={errors.QUANTITY}
            required
          />
          <FormField
            label="Order Date"
            name="ORDER_DATE"
            type="date"
            value={formData.ORDER_DATE?.split('T')[0] || ''}
            onChange={(e) => setFormData({ ...formData, ORDER_DATE: e.target.value })}
            error={errors.ORDER_DATE}
            required
          />
          <FormField
            label="Status"
            name="STATUS"
            type="select"
            value={formData.STATUS}
            onChange={(e) => setFormData({ ...formData, STATUS: e.target.value })}
            error={errors.STATUS}
            options={[
              { value: 'Pending', label: 'Pending' },
              { value: 'Processing', label: 'Processing' },
              { value: 'Shipped', label: 'Shipped' },
              { value: 'Delivered', label: 'Delivered' }
            ]}
            required
          />
          <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="btn btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
            >
              {editingOrder ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Orders;
