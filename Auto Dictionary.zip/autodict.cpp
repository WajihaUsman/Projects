#include<iostream>

#include <cstring> #include

<vector> using namespace std;

struct node { char k[20];

// Keyword char m[100];

// Meaning char

synonyms[100]; // Synonyms

char antonyms[100]; //

Antonyms

 node* left; // Pointer to left child

node* right; // Pointer to right child

};

// Function prototypes void insert(node*& root, node* temp); void disp(node* root); int search(node* root,

const char* k); node* findMin(node* root); node* deleteNode(node* root, const char* k); void

update(node* root, const char* k, const char* newMeaning, const char* newSynonyms, const char*

newAntonyms); void autoComplete(node* root, const char* prefix); bool printWordsStartingWith(node*

root, const char* prefix); int wordCount(node* root); void freeMemory(node* root); void

inOrderTraversal(node* root, vector<node*>& nodes); node* sortedArrayToBST(vector<node*>& nodes, int

start, int end); node* sortAndDisplay(node* root); void loading(); void displayBookCover() {

 cout << "

*******************************************************************************" << endl;

 cout << " * WELCOME TO THE DICTIONARY :) *" << endl;

 cout << "

*******************************************************************************" << endl;

 cout << " * *" << endl;

 cout << " * Explore the world of words and enhance your vocabulary! *" << endl;

 cout << " * *" << endl;

 cout << "

*******************************************************************************" << endl;

 cout << " * *" << endl;

cout << " * 1. Insert Word *" <<

endl; cout << " * 2. Search Word

*" << endl; cout << " * 3. Delete Word

*" << endl; cout << " * 4. Auto-Complete Word

*" << endl; cout << " * 5. Display Dictionary

*" << endl; cout << " * 6. Update Word

*" << endl; cout << " * 7. Word Count

*" << endl; cout << " * 8. Display Sorted Dictionary

*" << endl; cout << " * 9. Exit

*" << endl; cout << " *

*" << endl;

 cout << "

*******************************************************************************" << endl;

}

// Function to display the book back cover

void displayBookBackCover() { cout<<endl;

 cout << "

*******************************************************************************" << endl; cout <<

" * THANK YOU FOR USING THE DICTIONARY *" << endl;

 cout << "

*******************************************************************************" << endl;

 cout << " * *" << endl; cout <<

" * Expand your knowledge and keep exploring! *" <<

endl;

 cout << " * *" << endl;

 cout << "

*******************************************************************************" << endl;

}

void insert(node*& root, node*

temp) { if (root == NULL) {

root = temp;

 }

 else if (strcmp(temp->k, root->k) < 0) {

insert(root->left, temp);

 } else {

insert(root->right, temp);

 }

}

void disp(node* root) { if (root != NULL) { disp(root->left);

cout << " Keyword: " << root->k << "\nMeaning: " <<

root->m

 << "\n Synonyms: " << root->synonyms << "\nAntonyms: " << root->antonyms << "\n\n";

disp(root->right);

 }

}

int search(node* root, const char* k) { while (root != NULL) { if (strcmp(k, root->k) == 0) {

cout << " Keyword Found: " << root->k << "\n Meaning: " <<

root->m

 << "\n Synonyms: " << root->synonyms << "\n Antonyms: " << root->antonyms

<< endl; return 1;

 }

 else if (strcmp(k, root->k) < 0) {

root = root->left;

 } else {

root = root->right;

}

 }

 cout << " Keyword Not Found." <<

endl; return 0;

}

node* findMin(node* root) { while

(root->left != NULL) root = root->left;

return root;

}

node* deleteNode(node* root, const

char* k) { if (root == NULL) return root;

if (strcmp(k, root->k) < 0) { root->left

= deleteNode(root->left, k);

 }

 else if (strcmp(k, root->k) > 0) {

root->right = deleteNode(root->right, k);

 } else { if (root->left

== NULL) { node*

temp = root->right;

delete root; return

temp;

 }

 else if (root->right ==

NULL) { node* temp =

root->left; delete root;

return temp;

 }

 node* temp = findMin(root-

>right); strcpy(root->k, temp-

>k); strcpy(root->m, temp->m);

strcpy(root->synonyms, temp-

>synonyms); strcpy(root-

>antonyms, temp->antonyms);

root->right = deleteNode(root-

>right, temp->k);

 }

 return root;

}

void update(node* root, const char* k, const char* newMeaning, const char* newSynonyms, const char*

newAntonyms) { while (root != NULL) { if (strcmp(k, root->k) == 0) { strcpy(root->m,

newMeaning); strcpy(root->synonyms, newSynonyms); strcpy(root->antonyms, newAntonyms);

 cout << " Word details updated successfully." <<

endl; return;

 }

 else if (strcmp(k, root->k) < 0) {

root = root->left;

 } else {

root = root->right;

 }

 }

 cout << " Keyword not found, unable to update."

<< endl; }

bool printWordsStartingWith(node* root, const char*

prefix) { if (root == NULL) return false; bool found =

false; if (strncmp(root->k, prefix, strlen(prefix)) == 0) {

cout << root->k << ": " << root->m << endl; found =

true;

}

 if (strncmp(prefix, root->k, strlen(prefix)) <= 0) {

found = printWordsStartingWith(root->left, prefix) ||

found;

 }

 found = printWordsStartingWith(root->right, prefix) || found;

return found;

}

void autoComplete(node* root, const char* prefix) {

 cout << " Auto-complete suggestions for prefix '" << prefix << "':" <<

endl; bool found = printWordsStartingWith(root, prefix);

 if (!found) { cout << " No words found with the prefix '"

<< prefix << "'." << endl;

 }

}

int wordCount(node* root) { if (root == NULL) return

0; return 1 + wordCount(root->left) +

wordCount(root->right);

}

void freeMemory(node*

root) { if (root == NULL)

return; freeMemory(root-

>left); freeMemory(root-

>right); delete root;

}

node* sortAndDisplay(node* root) {

 if (root == NULL) {

return NULL;

 }

 vector<node*> sortedNodes; inOrderTraversal(root,

sortedNodes); return sortedArrayToBST(sortedNodes, 0,

sortedNodes.size() - 1);

}

void inOrderTraversal(node* root, vector<node*>&

nodes) { if (root == NULL) return;

inOrderTraversal(root->left, nodes);

nodes.push_back(root); inOrderTraversal(root-

>right, nodes);

}

node* sortedArrayToBST(vector<node*>& nodes, int start,

int end) { if (start > end) return NULL; int mid = start +

(end - start) / 2; node* root = nodes[mid]; root->left =

sortedArrayToBST(nodes, start, mid - 1); root->right =

sortedArrayToBST(nodes, mid + 1, end); return root;

}

void loading() { cout << "\n\n\n\t\t\t\t

Loading....Please Wait!\n\n"; char a = 177, b = 219;

 cout << "\t\t\t\t

"; for (int i = 0; i <= 15; i++) cout

<< a; cout << "\r";

 cout << "\t\t\t\t

"; for (int i = 0; i <= 15; i++) {

cout << b; for (int j = 0; j <=

1e7; j++);

 }

 cout << "\n";

}

int main() {

displayBookCover();

int ch; node* root = NULL; node* temp; temp = new

node; strcpy(temp->k, "happy"); strcpy(temp->m, "feeling

or showing pleasure or contentment"); strcpy(temp-

>synonyms, "joyful, content, pleased"); strcpy(temp-

>antonyms, "sad, unhappy, miserable"); temp->left =

temp->right = NULL; insert(root, temp); temp = new

node; strcpy(temp->k, "sad"); strcpy(temp->m,

"feeling or showing sorrow; unhappy"); strcpy(temp-

>synonyms, "unhappy, sorrowful, dejected");

strcpy(temp->antonyms, "happy, joyful, cheerful");

temp->left = temp->right = NULL; insert(root, temp);

temp = new node; strcpy(temp->k, "quick");

strcpy(temp->m, "moving fast or able to move fast");

strcpy(temp->synonyms, "fast, speedy, rapid");

strcpy(temp->antonyms, "slow, sluggish, lethargic");

temp->left = temp->right = NULL; insert(root, temp);

temp = new node; strcpy(temp->k, "slow");

strcpy(temp->m, "moving or operating, or designed to do

so, only at a low speed; not quick or fast");

strcpy(temp->synonyms, "sluggish, unhurried, leisurely");

strcpy(temp->antonyms, "quick, fast, rapid"); temp-

>left = temp->right = NULL; insert(root, temp); temp

= new node; strcpy(temp->k, "big"); strcpy(temp->m,

"of considerable size, extent, or intensity");

strcpy(temp->synonyms, "large, huge, immense");

strcpy(temp->antonyms, "small, tiny, minute"); temp-

>left = temp->right = NULL; insert(root, temp);

 temp = new node; strcpy(temp->k, "small"); strcpy(temp->m, "of a size that is less than normal or usual");

strcpy(temp->synonyms, "tiny, little, minute"); strcpy(temp->antonyms, "big, large, immense"); temp->left = temp-

>right = NULL; insert(root, temp); temp = new node; strcpy(temp->k, "strong"); strcpy(temp->m, "having the

power to move heavy weights or perform other physically demanding tasks"); strcpy(temp->synonyms, "powerful,

sturdy, muscular"); strcpy(temp->antonyms, "weak, frail, feeble"); temp->left = temp->right = NULL; insert(root,

temp); temp = new node; strcpy(temp->k, "weak"); strcpy(temp->m, "lacking the power to perform physically

demanding tasks; lacking physical strength and energy"); strcpy(temp->synonyms, "frail, feeble, fragile");

strcpy(temp->antonyms, "strong, sturdy, powerful"); temp->left = temp->right = NULL; insert(root, temp); temp =

new node; strcpy(temp->k, "hot"); strcpy(temp->m, "having a high degree of heat or a high temperature");

strcpy(temp->synonyms, "warm, scorching, boiling"); strcpy(temp->antonyms, "cold, cool, chilly"); temp->left =

temp->right = NULL; insert(root, temp); temp = new node; strcpy(temp->k, "cold"); strcpy(temp->m, "of or at a low or

relatively low temperature, especially when compared to the temperature of the human body"); strcpy(temp-

>synonyms, "chilly, freezing, frosty"); strcpy(temp->antonyms, "hot, warm, balmy"); temp->left = temp->right =

NULL; insert(root, temp); do { cout << "\n\n\n\t\t\t\t <<<<<<<<<< LET'S EXPLORE! >>>>>>>>>>";

cout<<endl; cout << "\n\t\t\t 1.INSERT WORD"; cout << "\n\t\t\t

2.SEARCH WORD"; cout << "\n\t\t\t 3.DELETE WORD"; cout << "\n\t\t\t

4.AUTOCOMPLETE WORD"; cout << "\n\t\t\t 5.DISPLAY DICTIONARY"; cout << "\n\t\t\t

6.UPDATE WORD"; cout << "\n\t\t\t 7.WORD COUNT"; cout << "\n\t\t\t

8.DISPLAY SORTED DICTIONARY";

 cout << "\n\t\t 9.EXIT";

cout << "\n\n\t\t\t Enter your choice:

"; cin >> ch; switch (ch) { case 1:

 loading();

temp = new node;

 cout << "\n Enter

Keyword: "; cin >> temp->k; cout << "

Enter Meaning: "; cin.ignore();

cin.getline(temp->m, 100);

 cout << " Enter Synonyms: ";

 cin.getline(temp->synonyms, 100);

 cout << " Enter Antonyms: ";

 cin.getline(temp->antonyms, 100);

temp->left = temp->right = NULL;

insert(root, temp); cout<<"

Keyword entered successfully!";

cout<<endl; displayBookBackCover();

 break;

case 2:

 loading(); char searchKey[20]; cout << "\n

Enter keyword to search: "; cin >> searchKey;

search(root, searchKey); displayBookBackCover();

 break;

case 3:

 loading(); char deleteKey[20]; cout << "\n

Enter keyword to delete: "; cin >> deleteKey; root =

deleteNode(root, deleteKey);

 cout << "\n Keyword deleted

successfully.\n"; displayBookBackCover(); break; case 4:

 loading(); char prefix[20]; cout << "\n

Enter prefix to auto-complete: "; cin >> prefix;

autoComplete(root, prefix); displayBookBackCover(); break;

case 5:

 loading();

 disp(root);

 displayBookBackCover(); break;

case 6:

 loading();

 char updateKey[20], newMeaning[100], newSynonyms[100], newAntonyms[100];

 cout << "\n Enter keyword to

update: "; cin >> updateKey; cout << "

Enter new Meaning: "; cin.ignore();

cin.getline(newMeaning, 100);

 cout << " Enter new Synonyms: ";

 cin.getline(newSynonyms, 100);

 cout << " Enter new Antonyms: ";

 cin.getline(newAntonyms, 100); update(root,

updateKey, newMeaning, newSynonyms, newAntonyms);

displayBookBackCover(); break; case 7:

 loading(); cout << "\n Total words in the dictionary: "

<< wordCount(root) << "\n"; displayBookBackCover(); break;

 case 8:

 loading(); root = sortAndDisplay(root); cout << "\n

Dictionary sorted and displayed.\n"; disp(root);

displayBookBackCover(); break;

 case 9: loading();

displayBookBackCover(); break;

 default:

 cout << " :( Invalid choice. Please try again." << endl;

 } }

while (ch != 9);

return 0;

}
