import tkinter as tk
from tkinter import messagebox, ttk
from functools import partial
import time

# Caesar Cipher Encryption Function
def caesar_encrypt(plain_text, shift):
    encrypted = ""
    for char in plain_text:
        if char.isalpha():
            shift_base = ord('A') if char.isupper() else ord('a')
            encrypted += chr((ord(char) - shift_base + shift) % 26 + shift_base)
        else:
            encrypted += char
    return encrypted

# Affine Cipher Encryption Function
def affine_encrypt(plain_text, a, b):
    encrypted = ""
    for char in plain_text:
        if char.isalpha():
            shift_base = ord('A') if char.isupper() else ord('a')
            encrypted += chr(((a * (ord(char) - shift_base) + b) % 26) + shift_base)
        else:
            encrypted += char
    return encrypted

# Vigenere Cipher Encryption Function
def vigenere_encrypt(plain_text, key):
    encrypted = ""
    key_len = len(key)
    key_index = 0
    for char in plain_text:
        if char.isalpha():
            shift_base = ord('A') if char.isupper() else ord('a')
            shift = ord(key[key_index % key_len].upper()) - ord('A')
            encrypted += chr((ord(char) - shift_base + shift) % 26 + shift_base)
            key_index += 1
        else:
            encrypted += char
    return encrypted

class EscapeRoom:
    def _init_(self, root, username):
        self.root = root
        self.username = username
        self.root.title("Cyber Escape Room")
        self.root.geometry("600x400")
        self.root.configure(bg="#0a0a0a")  # Dark background for the main window

        self.level = 1
        self.time_remaining = 300
        self.progress = 0
        self.score = 0  # Track user score
        self.start_time = time.time()  # Store the start time when the game begins

        self.title_label = tk.Label(
            self.root,
            text=f"Welcome, {self.username} TO CYBER ESCAPE ROOM",
            font=("Helvetica", 18, "bold"),
            bg="#0a0a0a",  # Dark background
            fg="#ff0000"    # Red text for spooky effect
        )
        self.title_label.pack(pady=10)

        self.timer_label = tk.Label(
            self.root,
            text=f"Time Remaining: {self.time_remaining}s",
            font=("Arial", 14),
            bg="#0a0a0a",  # Dark background
            fg="white"     # White text for readability
        )
        self.timer_label.pack()

        self.progress_bar = ttk.Progressbar(
            self.root, length=400, maximum=3, style="red.Horizontal.TProgressbar"
        )
        self.progress_bar.pack(pady=10)

        self.main_frame = tk.Frame(self.root, bg="#252535")  # Darker frame for spooky feel
        self.main_frame.pack(fill="both", expand=True, padx=20, pady=10)

        self.setup_level()
        self.start_timer()

    def setup_level(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

        if self.level == 1:
            self.plain_text = "HELLO"
            self.encryption_func = partial(caesar_encrypt, shift=3)
            self.hint = "Hint: Shift each letter by 3 positions to the right. Example: A -> D."
            self.prompt = "Level 1: Encrypt the Plain Text using Caesar Cipher."
        elif self.level == 2:
            self.plain_text = "HELLO"
            self.encryption_func = partial(affine_encrypt, a=5, b=8)
            self.hint = "Hint: Use the formula (5 * x + 8) mod 26, where x is the letter's position (A=0, B=1, ...)."
            self.prompt = "Level 2: Encrypt the Plain Text using Affine Cipher."
        elif self.level == 3:
            self.plain_text = "HELLO"
            self.encryption_func = partial(vigenere_encrypt, key="KEY")
            self.hint = "Hint: Use the key 'KEY' to shift each letter. Repeat the key until it matches the text length."
            self.prompt = "Level 3: Encrypt the Plain Text using Vigenère Cipher."
        else:
            self.show_final_score()
            return

        # GUI Setup for each level
        tk.Label(
            self.main_frame,
            text=self.prompt,
            font=("Arial", 16),
            bg="#252535",
            fg="#ff0000"  # Red text for spooky effect
        ).pack(pady=10)

        tk.Label(
            self.main_frame,
            text=f"Plain Text: {self.plain_text}",
            font=("Arial", 14),
            bg="#252535",
            fg="white"  # White text for readability
        ).pack(pady=5)

        tk.Label(
            self.main_frame,
            text=self.hint,
            font=("Arial", 12, "italic"),
            bg="#252535",
            fg="#ff6347"  # Light red for the hint
        ).pack(pady=5)

        self.user_input = tk.Entry(self.main_frame, font=("Arial", 14), bg="#353535", fg="white")
        self.user_input.pack(pady=10)

        tk.Button(
            self.main_frame,
            text="Submit",
            command=self.check_answer,
            font=("Arial", 14),
            bg="#8b0000",  # Dark red for buttons
            fg="white",
            activebackground="#ff0000",  # Brighter red for active state
            activeforeground="black"
        ).pack(pady=10)

    def check_answer(self):
        user_answer = self.user_input.get().strip().upper()
        correct_answer = self.encryption_func(self.plain_text).upper()

        if user_answer == correct_answer:
            self.score += 10  # Increase score for correct answer
            self.show_level_complete()
        else:
            self.show_try_again()

    def show_level_complete(self):
        complete_window = tk.Toplevel(self.root)
        complete_window.geometry("400x200")
        complete_window.title("Level Completed!")
        complete_window.configure(bg="#0a0a0a")  # Dark background

        message = tk.Label(
            complete_window,
            text="Congratulations! You solved the level.",
            font=("Arial", 16, "bold"),
            bg="#0a0a0a",  # Dark background
            fg="#ff0000"    # Red text for spooky effect
        )
        message.pack(pady=40)

        next_button = tk.Button(
            complete_window,
            text="Next Level",
            command=lambda: self.proceed_to_next_level(complete_window),
            font=("Arial", 14),
            bg="#8b0000",  # Dark red for button
            fg="white",
            activebackground="#ff0000",  # Brighter red for active state
            activeforeground="black"
        )
        next_button.pack(pady=10)

    def proceed_to_next_level(self, complete_window):
        complete_window.destroy()
        self.level += 1
        self.progress += 1
        self.progress_bar['value'] = self.progress
        self.setup_level()

    def show_try_again(self):
        messagebox.showwarning("Try Again", "Incorrect Answer! Try Again.")

    def show_final_score(self):
        # Calculate the time taken to finish the game
        end_time = time.time()
        time_taken = round(end_time - self.start_time)  # Time taken in seconds

        final_window = tk.Toplevel(self.root)
        final_window.geometry("400x200")
        final_window.title("Game Over")
        final_window.configure(bg="#0a0a0a")  # Dark background

        message = tk.Label(
            final_window,
            text=f"Congratulations! You escaped the Cyber Room successfully.\nTime Taken: {time_taken} seconds\nYour Final Score: {self.score}",
            font=("Arial", 16, "bold"),
            bg="#0a0a0a",  # Dark background
            fg="#ff0000"    # Red text for spooky effect
        )
        message.pack(pady=40)

        quit_button = tk.Button(
            final_window,
            text="Quit",
            command=self.root.quit,
            font=("Arial", 14),
            bg="#8b0000",  # Dark red for button
            fg="white",
            activebackground="#ff0000",  # Brighter red for active state
            activeforeground="black"
        )
        quit_button.pack(pady=10)

    def start_timer(self):
        if self.time_remaining > 0:
            self.time_remaining -= 1
            self.timer_label.config(text=f"Time Remaining: {self.time_remaining}s")
            self.root.after(1000, self.start_timer)
        else:
            self.show_final_score()

def start_game():
    username = username_entry.get().strip()
    password = password_entry.get().strip()

    # Password validation
    if username and password == "correct_password":
        root = tk.Tk()
        game = EscapeRoom(root, username)
        root.mainloop()
    else:
        messagebox.showwarning("Invalid Credentials", "Please enter a valid username and correct password.")

# Main GUI for entering the username and password
root = tk.Tk()
root.title("Welcome to Cyber Escape Room")
root.geometry("400x300")
root.configure(bg="#0a0a0a")

tk.Label(
    root,
    text="Enter your username:",
    font=("Arial", 16),
    bg="#0a0a0a",  # Dark background
    fg="white"     # White text for readability
).pack(pady=20)

username_entry = tk.Entry(root, font=("Arial", 14), bg="#353535", fg="white")
username_entry.pack(pady=10)

tk.Label(
    root,
    text="Enter your password:",
    font=("Arial", 16),
    bg="#0a0a0a",  # Dark background
    fg="white"     # White text for readability
).pack(pady=10)

password_entry = tk.Entry(root, font=("Arial", 14), bg="#353535", fg="white", show="*")
password_entry.pack(pady=10)

start_button = tk.Button(
    root,
    text="Start Game",
    command=start_game,
    font=("Arial", 14),
    bg="#8b0000",  # Dark red for button
    fg="white",
    activebackground="#ff0000",  # Brighter red for active state
    activeforeground="black"
)
start_button.pack(pady=20)

root.mainloop()